package examen;

public class Encargado extends Persona {
    private int aCargo;

    public Encargado(){
        
    }
    
    public int getaCargo() {
        return aCargo;
    }

    public void setaCargo(int aCargo) {
        this.aCargo = aCargo;
    }

    public Encargado(int aCargo, String nombre, int DNI, int ingreso, double sueldoBasico) {
        super(nombre, DNI, ingreso, sueldoBasico);
        this.aCargo = aCargo;
    }

    @Override
    public double sueldoCobrar(){
        if (2023-getIngreso()>=20)
           return getSueldoBasico()*1.1+1000*getaCargo();
        else
            return getSueldoBasico()+1000*getaCargo();
    }
    
     @Override
    public String toString(){
        String aux;
        aux="\n->Nombre: "+getNombre()+".\n->DNI: "+getDNI()+".\n->Sueldo a cobrar: $"+sueldoCobrar()+".";
        return aux;
    }
}
