package examen;
public abstract class Persona {
    private String nombre;
    private int DNI;
    private int ingreso;
    private double sueldoBasico;
    
    public Persona(){
        
    }

    public Persona(String nombre, int DNI, int ingreso, double sueldoBasico) {
        this.nombre = nombre;
        this.DNI = DNI;
        this.ingreso = ingreso;
        this.sueldoBasico = sueldoBasico;
    }
    
    public abstract double sueldoCobrar();

    public int getIngreso() {
        return ingreso;
    }

    public void setIngreso(int ingreso) {
        this.ingreso = ingreso;
    }

    public double getSueldoBasico() {
        return sueldoBasico;
    }

    public void setSueldoBasico(double sueldoBasico) {
        this.sueldoBasico = sueldoBasico;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getDNI() {
        return DNI;
    }

    public void setDNI(int DNI) {
        this.DNI = DNI;
    }
    
    
}
