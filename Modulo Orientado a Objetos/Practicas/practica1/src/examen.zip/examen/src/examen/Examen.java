//16:05-16:58
package examen;
import PaqueteLectura.Lector;
public class Examen {

    public static void main(String[] args) {
        Director d=new Director(777, "Mateo Mendoza Matus", 44933801, 2000, 200000);
        Empresa e=new Empresa("Carrefour Market", "7 e/ 47 y 48", 3, d);
        Encargado enc;
        int cant=2;
        int i;
        int aCargo,DNI,ingreso,sucursal;
        String nombre;
        double basico;
        for (i=0; i<cant; i++){
            System.out.println("===================================");
            System.out.print("Ingrese el nombre del encargado: "); nombre=Lector.leerString();
            System.out.println();
            System.out.print("Ingrese la cantidad de empleados a cargos que tiene: "); aCargo=Lector.leerInt();
            System.out.println();
            System.out.print("Ingrese el DNI del encargado: "); DNI=Lector.leerInt();
            System.out.println();
            System.out.print("Ingrese el año de incorporación a la empresa del mismo: "); ingreso=Lector.leerInt();
            System.out.println();
            System.out.print("Ingrese el sueldo básico asignado: $"); basico=Lector.leerDouble();
            System.out.println();
            enc=new Encargado(aCargo, nombre, DNI, ingreso, basico);
            System.out.print("Indique qué sucursal tiene a cargo: "); sucursal=Lector.leerInt(); //1, 2, 3
            e.addEncargado(enc, sucursal);
        }
        
        System.out.println(e.toString());
    }
    
}
