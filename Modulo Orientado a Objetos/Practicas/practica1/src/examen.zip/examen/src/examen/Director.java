package examen;

public class Director extends Persona{
    private double montoViaticos;
    
    public Director(){
        
    }

    public Director(double montoViaticos, String nombre, int DNI, int ingreso, double sueldoBasico) {
        super(nombre, DNI, ingreso, sueldoBasico);
        this.montoViaticos = montoViaticos;
    }

    public double getMontoViaticos() {
        return montoViaticos;
    }

    public void setMontoViaticos(double montoViaticos) {
        this.montoViaticos = montoViaticos;
    }

    @Override
    public double sueldoCobrar(){
        if (2023-getIngreso()>=20)
            return this.montoViaticos+getSueldoBasico()*1.1;
        else
            return getSueldoBasico();
    }

    @Override
    public String toString(){
        String aux;
        aux="\n->Nombre: "+getNombre()+".\n->DNI: "+getDNI()+".\n->Sueldo a cobrar: $"+sueldoCobrar()+".";
        return aux;
    }
}
