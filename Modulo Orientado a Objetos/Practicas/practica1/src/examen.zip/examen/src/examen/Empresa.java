package examen;

public class Empresa {
    private String nombre;
    private String direccion;
    private Encargado [] vectorE;
    private int dimF;
    private Director director;

    public Empresa(){
        
    }
    
    public Empresa(String nombre, String direccion, int dimF, Director director) {
        this.nombre = nombre;
        this.direccion = direccion;
        this.dimF = dimF;
        this.director = director;
        this.vectorE=new Encargado [dimF];
    }
    
    public void addEncargado (Encargado e, int pos){
        this.vectorE[pos-1]=e;
    }
    

    @Override
    public String toString(){
        String aux;
        int i;
        aux="======================"
                + "\nNombre de la empresa: "+getNombre()+"."
                + "\nDirección de la empresa: "+getDireccion()+"."
                + "\n======================"
                + "\nDirector de la empresa: "+this.director.toString();
        for (i=0; i<this.dimF; i++)
            if (this.vectorE[i]!=null)
                aux=aux+"\n========Encargado de sucursal "+(i+1)+"=========="+this.vectorE[i].toString();
            else    
                aux=aux+"\n======================"
                        + "\nLa sucursal "+(i+1)+" no tiene un encargado asignado."
                        + "\n======================";
        return aux;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
    
    
}
